export interface AnalysisResult {
  overallScore: number;
  summary: string;
  strengths: string[];
  weaknesses: string[];
  suggestions: string[];
  dimensionScores: Record<string, number>;
  improvedResume: string;
}

interface DimensionResult {
  score: number;
  strengths: string[];
  weaknesses: string[];
  suggestions: string[];
}

function countWords(text: string): number {
  return text.trim().split(/\s+/).filter(Boolean).length;
}

function sectionScore(text: string): DimensionResult {
  const strengths: string[] = [];
  const weaknesses: string[] = [];
  const suggestions: string[] = [];

  const sections = [
    /summary|objective|profile/i,
    /experience|work\s*history|employment/i,
    /education|academic/i,
    /skills|competencies|expertise/i,
    /projects?/i,
    /certifications?|licenses?/i,
    /achievements?|accomplishments/i,
    /leadership|volunteer/i,
  ];

  const foundSections = sections.filter((r) => r.test(text));
  const sectionCount = foundSections.length;

  const wordCount = countWords(text);

  let score = 0;

  if (sectionCount >= 5) {
    score += 35;
    strengths.push("Includes a comprehensive set of resume sections");
  } else if (sectionCount >= 3) {
    score += 25;
    strengths.push("Covers the essential resume sections");
  } else {
    score += 10;
    weaknesses.push("Missing several key sections (e.g., Experience, Education, Skills)");
    suggestions.push("Add these key sections: Professional Summary, Work Experience, Education, Skills, and Projects/Certifications");
  }

  if (wordCount >= 300 && wordCount <= 800) {
    score += 15;
    strengths.push("Resume length is ideal (300–800 words)");
  } else if (wordCount < 200) {
    score += 5;
    weaknesses.push("Resume is too short; consider adding more detail");
    suggestions.push("Expand your resume to at least 300 words with detailed experience descriptions");
  } else if (wordCount > 1000) {
    score += 8;
    weaknesses.push("Resume is quite long; consider trimming to be more concise");
    suggestions.push("Aim for 500–700 words — be concise and focus on the most relevant experience");
  } else {
    score += 10;
  }

  // Check for contact info
  if (/\b[\w.-]+@[\w.-]+\.\w+\b/.test(text)) {
    score += 5;
    strengths.push("Includes email contact information");
  } else {
    weaknesses.push("Missing email contact information");
    suggestions.push("Add your email address at the top of your resume");
  }

  if (/\b(linkedin\.com|github\.com|portfolio|personal\s*website)\b/i.test(text)) {
    score += 5;
    strengths.push("Includes links to professional profiles (LinkedIn, GitHub, etc.)");
  } else {
    suggestions.push("Consider adding LinkedIn and GitHub profile links");
    weaknesses.push("No professional profile links found");
  }

  // Check for clear headings (ALL CAPS or bold-like)
  const headingLines = text.split("\n").filter(
    (l) => l.trim() && (l.trim() === l.trim().toUpperCase() || /^#{1,3}\s/.test(l.trim()))
  );
  if (headingLines.length >= 3) {
    score += 5;
    strengths.push("Clear section headings make your resume easy to skim");
  } else {
    suggestions.push("Use clear, distinct headings for each section");
  }

  return {
    score: Math.min(score, 65),
    strengths,
    weaknesses,
    suggestions,
  };
}

function contentQualityScore(text: string): DimensionResult {
  const strengths: string[] = [];
  const weaknesses: string[] = [];
  const suggestions: string[] = [];

  let score = 0;

  // Check for action verbs
  const actionVerbs = [
    "achieved", "managed", "led", "developed", "created", "implemented",
    "designed", "improved", "increased", "decreased", "reduced", "delivered",
    "established", "launched", "optimized", "transformed", "built", "drove",
    "generated", "spearheaded", "negotiated", "coordinated", "executed",
    "administered", "produced", "engineered", "deployed", "architected",
  ];
  const foundVerbs = actionVerbs.filter((v) => new RegExp(`\\b${v}\\b`, "i").test(text));
  if (foundVerbs.length >= 5) {
    score += 20;
    strengths.push("Strong use of action verbs to describe achievements");
  } else if (foundVerbs.length >= 2) {
    score += 12;
    strengths.push("Some action verbs used");
    suggestions.push("Use more powerful action verbs like 'achieved', 'led', 'implemented', 'optimized'");
  } else {
    score += 4;
    weaknesses.push("Few action verbs — bullet points read as responsibilities, not achievements");
    suggestions.push("Start each bullet point with a strong action verb (e.g., 'Achieved', 'Led', 'Implemented')");
  }

  // Check for quantifiable achievements
  const percentPattern = /\d+%/g;
  const dollarPattern = /\$[\d,]+/g;
  const numberPattern = /\b\d+\s*(?:x|times|people|clients|customers|users|projects|team|members|countries|revenue|sales|growth|improvement|increase|decrease|reduction)\b/gi;

  const percentMatches = text.match(percentPattern);
  const dollarMatches = text.match(dollarPattern);
  const numberPhraseMatches = text.match(numberPattern);

  const quantCount = (percentMatches?.length || 0) + (dollarMatches?.length || 0) + (numberPhraseMatches?.length || 0);

  if (quantCount >= 4) {
    score += 25;
    strengths.push("Excellent use of quantifiable achievements (percentages, dollar amounts, metrics)");
  } else if (quantCount >= 2) {
    score += 16;
    strengths.push("Some quantifiable results included");
    suggestions.push("Add more metrics — hiring managers love specific numbers and percentages");
  } else if (quantCount >= 1) {
    score += 8;
    suggestions.push("Add quantifiable achievements with percentages, dollar figures, or other metrics");
    weaknesses.push("Few quantifiable results — add numbers to strengthen your impact");
  } else {
    score += 2;
    weaknesses.push("No quantifiable achievements found — use numbers to demonstrate impact");
    suggestions.push("Add specific metrics: 'Increased X by Y%', 'Managed $Z budget', 'Led team of N people'");
  }

  // Check for keywords
  const keywordCategories = [
    { name: "management", words: /\b(leadership|managed|team|strategy|stakeholder|mentor|supervis(e|or)|director)\b/i },
    { name: "technical", words: /\b(software|programming|data|analytics|system|platform|infrastructure|cloud|api|database)\b/i },
    { name: "communication", words: /\b(communicat(e|ion)|presented|report|document|collaborat(e|ion)|presentation|written)\b/i },
    { name: "results", words: /\b(result|outcome|impact|improve|grow|increase|reduce|achieve|deliver)\b/i },
    { name: "problem solving", words: /\b(solv(e|ing)|analy(z|s)ed|troubleshoot|innovative|solution|optimize|resolv(e|ing))\b/i },
  ];

  const matchedCategories = keywordCategories.filter((c) => c.words.test(text));
  if (matchedCategories.length >= 4) {
    score += 15;
    strengths.push("Strong coverage of key competency areas");
  } else if (matchedCategories.length >= 2) {
    score += 8;
    suggestions.push("Include keywords from more competency areas (leadership, results, technical skills)");
  } else {
    score += 2;
    weaknesses.push("Limited keyword coverage — tailor your resume with industry-relevant terms");
    suggestions.push("Research job descriptions in your field and incorporate relevant keywords");
  }

  return {
    score: Math.min(score, 60),
    strengths,
    weaknesses,
    suggestions,
  };
}

function experienceSkillsScore(text: string): DimensionResult {
  const strengths: string[] = [];
  const weaknesses: string[] = [];
  const suggestions: string[] = [];

  let score = 0;

  // Check for experience section
  const hasExperience = /\b(experience|work\s*history|employment)\b/i.test(text);
  if (hasExperience) {
    score += 15;
    strengths.push("Has a dedicated work experience section");

    // Check for depth in experience
    const bulletPoints = (text.match(/[•●■➢\-*\n]\s+[A-Z]/g) || []).length;
    if (bulletPoints >= 8) {
      score += 10;
      strengths.push("Detailed experience with multiple bullet points per role");
    } else if (bulletPoints >= 4) {
      score += 5;
      suggestions.push("Add more bullet points (4–6 per role) with detailed achievements");
    } else {
      weaknesses.push("Experience section lacks detail — aim for 4–6 bullet points per role");
      suggestions.push("Expand each role with 4–6 bullet points describing specific achievements");
    }
  } else {
    weaknesses.push("No work experience section found");
    suggestions.push("Add a dedicated 'Work Experience' or 'Professional Experience' section");
  }

  // Check for skills section
  const hasSkills = /\b(skills|core\s*competencies|technical\s*skills|expertise)\b/i.test(text);
  if (hasSkills) {
    score += 15;
    strengths.push("Includes a dedicated skills section");
  } else {
    weaknesses.push("No dedicated skills section");
    suggestions.push("Add a 'Skills' section listing technical and soft skills");
  }

  // Check for education
  if (/\b(education|bachelor|master|phd|b\.?[as]c?\.?|m\.?[as]c?\.?|ph\.?d|bs\s|ba\s|ms\s|ma\s|university|college|school)\b/i.test(text)) {
    score += 10;
    strengths.push("Education credentials are listed");
  } else {
    weaknesses.push("No education information found");
    suggestions.push("Add your educational background including degree, institution, and graduation year");
  }

  // Check for technical skills listing
  const techSkills = [
    "python", "javascript", "typescript", "java", "c\\+\\+|c#", "ruby", "go", "rust",
    "react", "angular", "vue", "node", "django", "flask", "spring", "express",
    "sql", "nosql", "mongodb", "postgresql", "mysql", "redis",
    "aws", "azure", "gcp", "docker", "kubernetes", "ci/cd",
    "git", "linux", "agile", "scrum", "rest", "graphql",
  ];

  const foundTechSkills = techSkills.filter((s) => new RegExp(`\\b${s}\\b`, "i").test(text));
  if (foundTechSkills.length >= 6) {
    score += 10;
    strengths.push(`Lists ${foundTechSkills.length} relevant technical skills`);
  } else if (foundTechSkills.length >= 2) {
    score += 5;
    suggestions.push("Consider adding more specific technical skills to strengthen your profile");
  }

  // Check for certifications
  if (/\b(certif|license|pmp|aws\s*certif|google\s*certif|scrum|itil|six\s*sigma|cissp|cpa|cfa|comptia)\b/i.test(text)) {
    score += 5;
    strengths.push("Certifications and professional credentials are listed");
    suggestions.push("If you have more certifications, list them in a dedicated section");
  }

  // Check for soft skills
  const softSkills = [
    "communicat", "teamwork", "leadership", "problem.solv", "critical.think",
    "time.manag", "adaptab", "collaborat", "interpersonal", "organiz",
  ];
  const foundSoftSkills = softSkills.filter((s) => new RegExp(`\\b${s}`, "i").test(text));
  if (foundSoftSkills.length >= 3) {
    score += 5;
    strengths.push("Includes relevant soft skills");
  } else {
    suggestions.push("Mention soft skills like communication, teamwork, and leadership");
  }

  return {
    score: Math.min(score, 60),
    strengths,
    weaknesses,
    suggestions,
  };
}

function atsKeywordScore(text: string): DimensionResult {
  const strengths: string[] = [];
  const weaknesses: string[] = [];
  const suggestions: string[] = [];

  let score = 0;

  // Common ATS keywords across industries
  const atsKeywords = [
    // Leadership
    "leadership", "team management", "strategic planning", "stakeholder",
    "cross-functional", "mentoring", "budget management",
    // Technical
    "agile", "scrum", "devops", "full stack", "frontend", "backend",
    "database", "api", "microservices", "cloud", "software development",
    "qa", "testing", "deployment", "version control",
    // Business
    "revenue", "profit", "roi", "kpi", "p&l", "business development",
    "market", "sales", "customer", "client", "vendor",
    // Data
    "data analysis", "data science", "machine learning", "statistics",
    "visualization", "reporting", "analytics", "metrics",
    // Soft
    "communication", "presentation", "negotiation", "conflict resolution",
    "project management", "time management", "problem solving",
  ];

  const foundKeywords = atsKeywords.filter((kw) => new RegExp(`\\b${kw}\\b`, "i").test(text));
  const keywordDensity = foundKeywords.length;

  if (keywordDensity >= 12) {
    score += 30;
    strengths.push("Excellent ATS keyword optimization — your resume will rank well");
  } else if (keywordDensity >= 7) {
    score += 20;
    strengths.push("Good ATS keyword coverage");
    suggestions.push("Add more industry-specific keywords to improve ATS ranking");
  } else if (keywordDensity >= 3) {
    score += 10;
    suggestions.push("Incorporate more ATS-friendly keywords from job descriptions in your field");
    weaknesses.push("Limited ATS keyword presence");
  } else {
    score += 3;
    weaknesses.push("Very few ATS keywords detected — your resume may be filtered out");
    suggestions.push("Add industry-specific keywords throughout your experience descriptions");
  }

  // Check for job title relevance
  const jobTitles = [
    "engineer", "developer", "manager", "director", "analyst", "consultant",
    "architect", "lead", "senior", "junior", "associate", "coordinator",
    "specialist", "supervisor", "administrator", "officer", "head of",
  ];
  const foundTitles = jobTitles.filter((t) => new RegExp(`\\b${t}\\b`, "i").test(text));
  if (foundTitles.length >= 2) {
    score += 10;
    strengths.push("Clearly indicates job titles and seniority levels");
  } else {
    suggestions.push("Make sure your job titles are clearly listed for each role");
  }

  // Check for formatting that might confuse ATS
  const hasTables = /[\t]{2,}|[│┃]/g.test(text);
  const hasMultipleColumns =
    text.split("\n").filter((l) => l.trim() && l.split(/\s{3,}/).length >= 2).length > 5;

  if (hasTables || hasMultipleColumns) {
    weaknesses.push("Complex formatting (tables/multi-column) may confuse ATS parsers");
    suggestions.push("Use a simple single-column layout for ATS compatibility");
    score -= 5;
  } else {
    score += 5;
    strengths.push("Clean, ATS-friendly formatting");
  }

  return {
    score: Math.max(0, Math.min(score, 45)),
    strengths,
    weaknesses,
    suggestions,
  };
}

function overallImpactScore(
  text: string,
  sectionRes: DimensionResult,
  contentRes: DimensionResult,
  expRes: DimensionResult,
  atsRes: DimensionResult
): DimensionResult {
  const strengths: string[] = [];
  const weaknesses: string[] = [];
  const suggestions: string[] = [];

  const avgScore =
    (sectionRes.score + contentRes.score + expRes.score + atsRes.score) / 4;

  let score = 0;

  // Check for a compelling summary/objective
  const summarySection = text.match(
    /(?:professional\s+)?(?:summary|objective|profile|about\s+me)[:\s]*([^\n]+(?:\n[^\n]+){0,4})/i
  );
  if (summarySection) {
    const summaryText = summarySection[1];
    const summaryWords = countWords(summaryText);
    if (summaryWords >= 15 && summaryWords <= 60) {
      score += 20;
      strengths.push("Well-crafted professional summary — concise and impactful");
    } else if (summaryWords > 0) {
      score += 10;
      suggestions.push("Your professional summary should be 2–4 sentences highlighting your key achievements and career goals");
    }
  } else {
    score += 3;
    weaknesses.push("No professional summary at the top of your resume");
    suggestions.push("Add a 2–3 sentence professional summary at the top summarizing your expertise and value proposition");
  }

  // Check resume starts strong
  const firstLine = text.split("\n")[0]?.trim() || "";
  if (firstLine && /[A-Z]/.test(firstLine[0])) {
    score += 5;
  }

  // Check for tailored content (customization)
  if (avgScore >= 25) {
    score += 10;
  }

  // Check for recency of information
  const years = text.match(/\b(20\d{2})\b/g);
  if (years) {
    const recentYears = years.filter((y) => parseInt(y) >= 2020);
    if (recentYears.length >= 2) {
      score += 10;
      strengths.push("Shows recent and up-to-date professional experience");
    } else {
      suggestions.push("Ensure your most recent roles and education are highlighted");
    }
  } else {
    suggestions.push("Include dates for your experience and education");
  }

  // Check for projects section
  if (/\bprojects?\b/i.test(text)) {
    score += 5;
    strengths.push("Projects section demonstrates hands-on work");
  }

  return {
    score: Math.min(score, 40),
    strengths,
    weaknesses,
    suggestions,
  };
}

function generateImprovedResume(
  originalText: string,
  sectionRes: DimensionResult,
  contentRes: DimensionResult,
  expRes: DimensionResult,
  atsRes: DimensionResult
): string {
  const lines = originalText.split("\n");
  const wordCount = countWords(originalText);

  // Extract name if present (first line or near top)
  const nameLine =
    lines.find(
      (l) => l.trim() && !l.includes("@") && l.trim().split(/\s+/).length >= 2 && l.trim() === l.trim()
    ) || "YOUR NAME";

  // Extract email
  const emailMatch = originalText.match(/\b[\w.-]+@[\w.-]+\.\w+\b/);
  const email = emailMatch ? emailMatch[0] : "email@example.com";

  // Extract phone
  const phoneMatch = originalText.match(
    /(?:\+?\d{1,3}[-.\s]?)?\(?\d{2,4}\)?[-.\s]?\d{3,4}[-.\s]?\d{3,4}/
  );
  const phone = phoneMatch ? phoneMatch[0] : "(555) 123-4567";

  // Extract LinkedIn
  const linkedinMatch = originalText.match(/linkedin\.com\/[^\s,)]+/i);
  const linkedin = linkedinMatch ? linkedinMatch[0] : null;

  // Extract GitHub
  const githubMatch = originalText.match(/github\.com\/[^\s,)]+/i);
  const github = githubMatch ? githubMatch[0] : null;

  // Extract existing skills
  const skillLines: string[] = [];
  const inSkills = lines.some(
    (l) => /\b(skills|core\s*competencies|technical\s*skills|expertise)\b/i.test(l)
  );

  // Build an improved resume
  const hasSummary = /\b(professional\s+)?(summary|objective|profile)\b/i.test(originalText);
  const hasExperience = /\b(experience|work\s*history)\b/i.test(originalText);
  const hasEducation = /\b(education)\b/i.test(originalText);
  const hasProjects = /\bprojects?\b/i.test(originalText);

  const improvedSections: string[] = [];

  improvedSections.push(
    "========================================",
    "           OPTIMIZED RESUME",
    "========================================",
    "",
  );

  // Contact header
  improvedSections.push(nameLine.toUpperCase());
  improvedSections.push("-".repeat(40));
  const contactItems = [email, phone];
  if (linkedin) contactItems.push(`LinkedIn: ${linkedin}`);
  if (github) contactItems.push(`GitHub: ${github}`);
  improvedSections.push("  " + contactItems.join("  |  "));
  improvedSections.push("");

  // Professional Summary
  improvedSections.push("PROFESSIONAL SUMMARY");
  improvedSections.push("-".repeat(40));
  if (hasSummary) {
    // Try to extract and enhance the existing summary
    const summaryLine = originalText.match(
      /(?:professional\s+)?(?:summary|objective|profile)[:\s]*([^\n]+(?:\n[^\n]+){0,4})/i
    );
    if (summaryLine) {
      improvedSections.push(summaryLine[1].trim());
    } else {
      improvedSections.push(
        "Results-driven professional with proven expertise in delivering impactful solutions. " +
          "Skilled in strategic planning, cross-functional collaboration, and driving measurable " +
          "business outcomes. Committed to continuous improvement and operational excellence."
      );
    }
  } else {
    improvedSections.push(
      "Results-driven professional with proven expertise in delivering impactful solutions. " +
        "Skilled in strategic planning, cross-functional collaboration, and driving measurable " +
        "business outcomes. Committed to continuous improvement and operational excellence."
    );
  }
  improvedSections.push("");

  // Core Competencies
  improvedSections.push("CORE COMPETENCIES");
  improvedSections.push("-".repeat(40));
  const commonSkills = [
    "Strategic Planning",
    "Team Leadership",
    "Project Management",
    "Data Analysis",
    "Cross-functional Collaboration",
    "Process Optimization",
  ];
  // Build 2 rows of skills
  const mid = Math.ceil(commonSkills.length / 2);
  improvedSections.push(
    "  " +
      commonSkills.slice(0, mid).join("  •  ")
  );
  improvedSections.push(
    "  " +
      commonSkills.slice(mid).join("  •  ")
  );
  improvedSections.push("");

  // Professional Experience
  improvedSections.push("PROFESSIONAL EXPERIENCE");
  improvedSections.push("-".repeat(40));

  if (hasExperience) {
    // Try to identify experience section and extract roles
    const expStartIndex = lines.findIndex((l) => /\b(experience|work\s*history)\b/i.test(l));
    if (expStartIndex >= 0) {
      // Find the next major section after experience
      let expEndIndex = lines.length;
      const sectionHeaders = ["EDUCATION", "SKILLS", "PROJECTS", "CERTIFICATIONS", "AWARDS"];
      for (const header of sectionHeaders) {
        const idx = lines.findIndex(
          (l, i) => i > expStartIndex && new RegExp(`\\b${header}\\b`).test(l.toUpperCase()) && l.trim() === l.toUpperCase().trim()
        );
        if (idx >= 0 && idx < expEndIndex) expEndIndex = idx;
      }

      const expLines = lines.slice(expStartIndex, expEndIndex);
      // Extract company names, titles, dates
      const rolePattern = /([A-Z][A-Za-z\s&,.]+)\s*[|–-]\s*([A-Za-z\s]+)\s*[|–-]\s*(\d{4}\s*[–-]\s*(?:\d{4}|Present|Current))/;
      const roleMatch = originalText.match(rolePattern);
      if (roleMatch) {
        improvedSections.push(`  ${roleMatch[2]}  |  ${roleMatch[1]}  |  ${roleMatch[3]}`);
        improvedSections.push("");

        const bulletPoints = expLines.filter((l) => /^[\s]*[•●■➢\-*\d.]/.test(l.trim()));
        if (bulletPoints.length > 0) {
          bulletPoints.slice(0, 5).forEach((b) => {
            // Enhance bullet points with action verbs and metrics
            let enhanced = b.trim().replace(/^[•●■➢\-*\d.]+\s*/, "");
            if (!/^(achieved|managed|led|developed|created|implemented|designed|improved|increased|decreased|reduced|delivered|established|launched|optimized|transformed|built|drove)/i.test(enhanced)) {
              enhanced = `Led ${enhanced.toLowerCase()}`;
            }
            improvedSections.push(`  •  ${enhanced}`);
          });
        } else {
          improvedSections.push("  •  Led strategic initiatives that drove measurable business growth and operational efficiency");
          improvedSections.push("  •  Managed cross-functional teams to deliver complex projects on time and within budget");
          improvedSections.push("  •  Implemented process improvements resulting in 20% increase in productivity");
          improvedSections.push("  •  Developed data-driven strategies that improved key performance metrics by 15%");
          improvedSections.push("  •  Collaborated with stakeholders to align business objectives with execution plans");
        }
      } else {
        // Generic experience entry
        improvedSections.push("  Senior Professional  |  Company Name  |  2020 – Present");
        improvedSections.push("");
        improvedSections.push("  •  Led strategic initiatives that drove measurable business growth and operational efficiency");
        improvedSections.push("  •  Managed cross-functional teams to deliver complex projects on time and within budget");
        improvedSections.push("  •  Implemented process improvements resulting in 20% increase in productivity");
        improvedSections.push("  •  Developed data-driven strategies that improved key performance metrics by 15%");
        improvedSections.push("  •  Collaborated with stakeholders to align business objectives with execution plans");
      }
    }
  } else {
    improvedSections.push("  Senior Professional  |  Company Name  |  2020 – Present");
    improvedSections.push("");
    improvedSections.push("  •  Led strategic initiatives that drove measurable business growth and operational efficiency");
    improvedSections.push("  •  Managed cross-functional teams to deliver complex projects on time and within budget");
    improvedSections.push("  •  Implemented process improvements resulting in 20% increase in productivity");
    improvedSections.push("  •  Developed data-driven strategies that improved key performance metrics by 15%");
    improvedSections.push("  •  Collaborated with stakeholders to align business objectives with execution plans");
  }
  improvedSections.push("");

  // Education
  improvedSections.push("EDUCATION");
  improvedSections.push("-".repeat(40));
  if (hasEducation) {
    const eduStartIndex = lines.findIndex((l) => /\b(education)\b/i.test(l));
    if (eduStartIndex >= 0) {
      const eduLines = lines.slice(eduStartIndex + 1, eduStartIndex + 6);
      const eduContent = eduLines
        .filter((l) => l.trim() && !/^(education|skills|certif|project)/i.test(l.trim()))
        .slice(0, 3);
      if (eduContent.length > 0) {
        eduContent.forEach((l) => improvedSections.push(`  ${l.trim()}`));
      } else {
        improvedSections.push("  Bachelor of Science in [Your Field]  |  University Name  |  20XX");
        improvedSections.push("  •  Relevant Coursework: [Course 1], [Course 2], [Course 3]");
      }
    }
  } else {
    improvedSections.push("  Bachelor of Science in [Your Field]  |  University Name  |  20XX");
    improvedSections.push("  •  Relevant Coursework: [Course 1], [Course 2], [Course 3]");
  }
  improvedSections.push("");

  // Additional sections
  if (hasProjects) {
    improvedSections.push("KEY PROJECTS");
    improvedSections.push("-".repeat(40));
    improvedSections.push("  [Project Name]  —  Brief description of the project and your role");
    improvedSections.push("  •  Technologies: [Tech Stack]");
    improvedSections.push("  •  Key achievement or outcome");
    improvedSections.push("");
  }

  // Certifications
  improvedSections.push("CERTIFICATIONS & PROFESSIONAL DEVELOPMENT");
  improvedSections.push("-".repeat(40));
  improvedSections.push("  •  [Certification Name]  —  Issuing Organization  —  20XX");
  improvedSections.push("  •  [Certification Name]  —  Issuing Organization  —  20XX");
  improvedSections.push("");

  // Technical Skills
  improvedSections.push("TECHNICAL SKILLS");
  improvedSections.push("-".repeat(40));
  improvedSections.push("  Languages & Frameworks:   [List relevant languages and frameworks]");
  improvedSections.push("  Tools & Platforms:        [List relevant tools and platforms]");
  improvedSections.push("  Databases & Cloud:        [List relevant databases and cloud services]");
  improvedSections.push("");

  improvedSections.push("-".repeat(50));
  improvedSections.push("NOTE: Content in brackets [ ] should be customized to your actual experience.");
  improvedSections.push("This optimized template follows ATS-friendly formatting and highlights");
  improvedSections.push("achievements with quantifiable results wherever possible.");

  return improvedSections.join("\n");
}

export function analyzeResume(text: string): AnalysisResult {
  if (!text || text.trim().length < 10) {
    return {
      overallScore: 0,
      summary: "The provided text is too short to analyze. Please paste a complete resume.",
      strengths: [],
      weaknesses: ["Resume text is too short or empty"],
      suggestions: ["Paste a complete resume with your experience, skills, and education"],
      dimensionScores: {
        "Format & Structure": 0,
        "Content Quality": 0,
        "Experience & Skills": 0,
        "ATS Optimization": 0,
        "Overall Impact": 0,
      },
      improvedResume: "Provide more resume content to receive a tailored improved version.",
    };
  }

  const sectionRes = sectionScore(text);
  const contentRes = contentQualityScore(text);
  const expRes = experienceSkillsScore(text);
  const atsRes = atsKeywordScore(text);
  const impactRes = overallImpactScore(text, sectionRes, contentRes, expRes, atsRes);

  const dimensionScores: Record<string, number> = {
    "Format & Structure": Math.round(sectionRes.score),
    "Content Quality": Math.round(contentRes.score),
    "Experience & Skills": Math.round(expRes.score),
    "ATS Optimization": Math.round(atsRes.score),
    "Overall Impact": Math.round(impactRes.score),
  };

  const allStrengths = [
    ...sectionRes.strengths,
    ...contentRes.strengths,
    ...expRes.strengths,
    ...atsRes.strengths,
    ...impactRes.strengths,
  ];
  const allWeaknesses = [
    ...sectionRes.weaknesses,
    ...contentRes.weaknesses,
    ...expRes.weaknesses,
    ...atsRes.weaknesses,
    ...impactRes.weaknesses,
  ];
  const allSuggestions = [
    ...sectionRes.suggestions,
    ...contentRes.suggestions,
    ...expRes.suggestions,
    ...atsRes.suggestions,
    ...impactRes.suggestions,
  ];

  // Deduplicate while preserving order
  const strengths = [...new Set(allStrengths)];
  const weaknesses = [...new Set(allWeaknesses)];
  const suggestions = [...new Set(allSuggestions)];

  // Calculate overall score out of 100
  const maxPossible = 65 + 60 + 60 + 45 + 40;
  const rawTotal = sectionRes.score + contentRes.score + expRes.score + atsRes.score + impactRes.score;
  const overallScore = Math.round((rawTotal / maxPossible) * 100);

  // Generate summary based on score
  let summary: string;
  if (overallScore >= 85) {
    summary =
      "Excellent resume! It's well-structured, rich with quantifiable achievements, and optimized for both human readers and ATS systems. Minor refinements can make it exceptional.";
  } else if (overallScore >= 70) {
    summary =
      "Good resume with solid structure and content. A few targeted improvements — especially adding more metrics and keywords — will significantly boost its effectiveness.";
  } else if (overallScore >= 50) {
    summary =
      "Your resume has a decent foundation but needs substantial improvement. Focus on adding quantifiable achievements, a professional summary, and more industry keywords to stand out.";
  } else if (overallScore >= 30) {
    summary =
      "Your resume needs significant work. Key areas to address: add a professional summary, structure your experience with bullet points, include measurable achievements, and add relevant keywords.";
  } else {
    summary =
      "This resume needs a complete overhaul. Follow the suggestions below to build a professional, ATS-optimized resume that effectively showcases your qualifications.";
  }

  const improvedResume = generateImprovedResume(text, sectionRes, contentRes, expRes, atsRes);

  return {
    overallScore: Math.min(100, Math.max(0, overallScore)),
    summary,
    strengths: strengths.slice(0, 8),
    weaknesses: weaknesses.slice(0, 8),
    suggestions: suggestions.slice(0, 8),
    dimensionScores,
    improvedResume,
  };
}
