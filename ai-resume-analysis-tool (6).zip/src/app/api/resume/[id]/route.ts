import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { resumes, resumeAnalyses } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const analysisId = parseInt(id, 10);

    if (isNaN(analysisId)) {
      return NextResponse.json({ error: "Invalid analysis ID." }, { status: 400 });
    }

    const analysis = await db
      .select()
      .from(resumeAnalyses)
      .where(eq(resumeAnalyses.id, analysisId))
      .limit(1);

    if (analysis.length === 0) {
      return NextResponse.json({ error: "Analysis not found." }, { status: 404 });
    }

    const resume = await db
      .select()
      .from(resumes)
      .where(eq(resumes.id, analysis[0].resumeId))
      .limit(1);

    return NextResponse.json({
      ...analysis[0],
      originalContent: resume[0]?.content || "",
    });
  } catch (error) {
    console.error("Analysis fetch error:", error);
    return NextResponse.json(
      { error: "Failed to fetch analysis." },
      { status: 500 }
    );
  }
}
