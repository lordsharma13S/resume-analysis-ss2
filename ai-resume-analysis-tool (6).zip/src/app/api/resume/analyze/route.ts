import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { resumes, resumeAnalyses } from "@/db/schema";
import { analyzeResume } from "@/ai/resumeAnalyzer";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { content } = body;

    if (!content || typeof content !== "string" || content.trim().length < 10) {
      return NextResponse.json(
        { error: "Please provide a resume with at least 10 characters." },
        { status: 400 }
      );
    }

    const trimmedContent = content.trim();

    // Save the original resume
    const [resume] = await db
      .insert(resumes)
      .values({ content: trimmedContent })
      .returning();

    // Run the analysis
    const analysis = analyzeResume(trimmedContent);

    // Save the analysis
    const [savedAnalysis] = await db
      .insert(resumeAnalyses)
      .values({
        resumeId: resume.id,
        overallScore: analysis.overallScore,
        summary: analysis.summary,
        strengths: analysis.strengths,
        weaknesses: analysis.weaknesses,
        suggestions: analysis.suggestions,
        dimensionScores: analysis.dimensionScores,
        improvedResume: analysis.improvedResume,
      })
      .returning();

    return NextResponse.json({
      id: savedAnalysis.id,
      resumeId: resume.id,
      overallScore: analysis.overallScore,
      summary: analysis.summary,
      strengths: analysis.strengths,
      weaknesses: analysis.weaknesses,
      suggestions: analysis.suggestions,
      dimensionScores: analysis.dimensionScores,
      improvedResume: analysis.improvedResume,
      createdAt: savedAnalysis.createdAt,
    });
  } catch (error) {
    console.error("Resume analysis error:", error);
    return NextResponse.json(
      { error: "Failed to analyze resume. Please try again." },
      { status: 500 }
    );
  }
}
