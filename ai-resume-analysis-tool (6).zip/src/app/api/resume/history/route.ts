import { NextResponse } from "next/server";
import { db } from "@/db";
import { resumes, resumeAnalyses } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const analyses = await db
      .select({
        id: resumeAnalyses.id,
        resumeId: resumeAnalyses.resumeId,
        overallScore: resumeAnalyses.overallScore,
        summary: resumeAnalyses.summary,
        createdAt: resumeAnalyses.createdAt,
        preview: resumes.content,
      })
      .from(resumeAnalyses)
      .innerJoin(resumes, eq(resumeAnalyses.resumeId, resumes.id))
      .orderBy(desc(resumeAnalyses.createdAt))
      .limit(20);

    const result = analyses.map((a) => ({
      ...a,
      preview: a.preview?.substring(0, 150) + (a.preview && a.preview.length > 150 ? "..." : ""),
    }));

    return NextResponse.json(result);
  } catch (error) {
    console.error("History fetch error:", error);
    return NextResponse.json(
      { error: "Failed to fetch history." },
      { status: 500 }
    );
  }
}
