import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "AI Resume Analyzer - Score & Optimize Your Resume",
  description: "Get your resume analyzed by AI across multiple dimensions. Receive a score, detailed feedback, and an optimized resume template.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-slate-100 text-slate-900 antialiased">{children}</body>
    </html>
  );
}
