import Link from "next/link";
import { db } from "@/db";
import { sql } from "drizzle-orm";
import { resumeAnalyses } from "@/db/schema";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  await db.execute(sql`select 1`);

  const recentAnalyses = await db
    .select({
      id: resumeAnalyses.id,
      overallScore: resumeAnalyses.overallScore,
      createdAt: resumeAnalyses.createdAt,
    })
    .from(resumeAnalyses)
    .orderBy(desc(resumeAnalyses.createdAt))
    .limit(5);

  return (
    <main className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-100">
      <div className="mx-auto max-w-4xl px-6 py-16">
        {/* Hero */}
        <section className="text-center">
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-indigo-600 to-purple-600 text-white shadow-lg mb-6">
            <svg className="h-8 w-8" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" d="m3.75 13.5 10.5-11.25L12 10.5h8.25L9.75 21.75 12 13.5H3.75Z" />
            </svg>
          </div>
          <h1 className="text-[clamp(2.2rem,5vw,3.5rem)] font-bold leading-[1.05] text-slate-950">
            AI Resume Analyzer
          </h1>
          <p className="mx-auto mt-4 max-w-2xl text-lg text-slate-600">
            Upload a resume image (PNG/JPG) for automatic OCR extraction, or paste the text directly. Get scored across <span className="font-semibold text-slate-800">5 dimensions</span> — structure, content quality, experience, ATS optimization, and overall impact. Receive actionable feedback and an optimized resume template.
          </p>
          <div className="mt-8 flex flex-col items-center gap-4 sm:flex-row sm:justify-center">
            <Link
              href="/resume"
              className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 px-8 py-3.5 text-sm font-semibold text-white shadow-md shadow-indigo-200 transition-all hover:from-indigo-700 hover:to-purple-700 hover:shadow-lg"
            >
              <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
              </svg>
              Analyze Your Resume
            </Link>
            {recentAnalyses.length > 0 && (
              <span className="text-sm text-slate-400">
                {recentAnalyses.length} analyses done so far
              </span>
            )}
          </div>
        </section>

        {/* Features */}
        <section className="mt-20 grid gap-6 md:grid-cols-3">
          {[
            {
              icon: "M3 16.5v2.25A2.25 2.25 0 0 0 5.25 21h13.5A2.25 2.25 0 0 0 21 18.75V16.5m-13.5-9L12 3m0 0 4.5 4.5M12 3v13.5",
              title: "Upload Image & OCR",
              desc: "Drag-and-drop resume images — Tesseract.js instantly extracts text for analysis.",
              color: "bg-sky-50 text-sky-600",
            },
            {
              icon: "M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z",
              title: "Smart Scoring",
              desc: "Comprehensive 5-dimension scoring system evaluates every aspect of your resume.",
              color: "bg-emerald-50 text-emerald-600",
            },
            {
              icon: "M12 18v-5.25m0 0a6.01 6.01 0 0 0 1.5-.189m-1.5.189a6.01 6.01 0 0 1-1.5-.189m3.75 7.478a12.06 12.06 0 0 1-4.5 0m3.75 2.383a14.406 14.406 0 0 1-3 0M14.25 18v-.192c0-.983.658-1.823 1.508-2.316a7.5 7.5 0 1 0-7.517 0c.85.493 1.509 1.333 1.509 2.316V18",
              title: "Actionable Feedback",
              desc: "Get specific, prioritized suggestions to improve your resume.",
              color: "bg-indigo-50 text-indigo-600",
            },
            {
              icon: "M12 3v17.25m0 0c-1.472 0-2.882.265-4.185.75M12 20.25c1.472 0 2.882.265 4.185.75M18.75 4.97A48.416 48.416 0 0012 4.5c-2.291 0-4.545.16-6.75.47m13.5 0c1.01.143 2.01.317 3 .52m-3-.52l2.62 10.726c.122.499-.106 1.028-.589 1.202a5.988 5.988 0 01-2.031.352 5.988 5.988 0 01-2.031-.352c-.483-.174-.711-.703-.589-1.202L18.75 4.971zm-12 0l-2.62 10.726c-.122.499.106 1.028.589 1.202a5.988 5.988 0 002.031.352 5.988 5.988 0 002.031-.352c.483-.174.711-.703.589-1.202L6.75 4.97z",
              title: "Optimized Template",
              desc: "Receive an ATS-friendly improved resume with enhanced wording and structure.",
              color: "bg-purple-50 text-purple-600",
            },
          ].map((feature, i) => (
            <div
              key={i}
              className="rounded-2xl bg-white p-6 border border-slate-200/60 shadow-[0_4px_20px_rgb(0,0,0,0.04)] transition-all hover:shadow-[0_8px_30px_rgb(0,0,0,0.08)]"
            >
              <div className={`flex h-10 w-10 items-center justify-center rounded-xl ${feature.color}`}>
                <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" d={feature.icon} />
                </svg>
              </div>
              <h3 className="mt-4 font-bold text-slate-900">{feature.title}</h3>
              <p className="mt-1 text-sm text-slate-500 leading-relaxed">{feature.desc}</p>
            </div>
          ))}
        </section>

        {/* Recent Analyses */}
        {recentAnalyses.length > 0 && (
          <section className="mt-16">
            <h2 className="text-lg font-bold text-slate-900 mb-4">Recent Analyses</h2>
            <div className="space-y-2">
              {recentAnalyses.map((a) => (
                <Link
                  key={a.id}
                  href={`/resume`}
                  className="flex items-center justify-between rounded-xl border border-slate-100 bg-white p-4 transition-all hover:border-indigo-200 hover:bg-indigo-50/50"
                >
                  <span className="text-sm text-slate-500">
                    {new Date(a.createdAt).toLocaleDateString("en-US", {
                      month: "short",
                      day: "numeric",
                      year: "numeric",
                    })}
                  </span>
                  <span
                    className={`rounded-lg px-2.5 py-1 text-xs font-bold ${
                      a.overallScore >= 80
                        ? "bg-emerald-100 text-emerald-700"
                        : a.overallScore >= 60
                          ? "bg-amber-100 text-amber-700"
                          : "bg-red-100 text-red-700"
                    }`}
                  >
                    Score: {a.overallScore}/100
                  </span>
                </Link>
              ))}
            </div>
          </section>
        )}

        {/* Footer */}
        <footer className="mt-16 text-center text-xs text-slate-400">
          <p>AI Resume Analyzer — Built with Next.js, Drizzle ORM, and PostgreSQL</p>
        </footer>
      </div>
    </main>
  );
}
