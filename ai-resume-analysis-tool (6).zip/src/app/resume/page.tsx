"use client";

import { useState, useRef, useEffect, useCallback } from "react";

export default function ResumePage() {
  const [resumeText, setResumeText] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [analysis, setAnalysis] = useState<AnalysisResponse | null>(null);
  const [activeTab, setActiveTab] = useState<"results" | "improved" | "history">("results");
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [loadingHistory, setLoadingHistory] = useState(false);
  const resultRef = useRef<HTMLDivElement>(null);

  // Image upload / OCR state
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [ocrProgress, setOcrProgress] = useState(0);
  const [ocrStatus, setOcrStatus] = useState<"idle" | "processing" | "done" | "error">("idle");
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  interface AnalysisResponse {
    id: number;
    resumeId: number;
    overallScore: number;
    summary: string;
    strengths: string[];
    weaknesses: string[];
    suggestions: string[];
    dimensionScores: Record<string, number>;
    improvedResume: string;
    createdAt: string;
  }

  interface HistoryItem {
    id: number;
    resumeId: number;
    overallScore: number;
    summary: string;
    createdAt: string;
    preview: string;
  }

  useEffect(() => {
    fetchHistory();
  }, []);

  async function fetchHistory() {
    setLoadingHistory(true);
    try {
      const res = await fetch("/api/resume/history");
      if (res.ok) {
        const data = await res.json();
        setHistory(data);
      }
    } catch {
      // silently fail
    } finally {
      setLoadingHistory(false);
    }
  }

  // --- OCR: Extract text from image ---
  const extractTextFromImage = useCallback(async (imageDataUrl: string) => {
    setOcrStatus("processing");
    setOcrProgress(0);
    setError("");

    try {
      // Dynamically import tesseract.js so it's never bundled server-side
      const Tesseract = await import("tesseract.js");
      const worker = await Tesseract.createWorker("eng", 1, {
        logger: (m: { status: string; progress: number }) => {
          if (m.status === "recognizing text") {
            setOcrProgress(Math.round(m.progress * 100));
          }
        },
      });

      const { data } = await worker.recognize(imageDataUrl);
      const extractedText = data.text.trim();

      await worker.terminate();

      if (extractedText.length < 5) {
        setError("Could not extract enough text from this image. Try a clearer image or paste the text manually.");
        setOcrStatus("error");
        return;
      }

      setResumeText((prev) => (prev ? prev + "\n\n--- OCR Extracted ---\n" + extractedText : extractedText));
      setOcrStatus("done");
    } catch (err) {
      console.error("OCR error:", err);
      setError("OCR processing failed. Please try a different image or paste the text manually.");
      setOcrStatus("error");
    }
  }, []);

  // --- Image upload handler ---
  const handleImageFile = useCallback((file: File) => {
    // Validate file type
    if (!file.type.startsWith("image/")) {
      setError("Please upload an image file (PNG, JPG, JPEG, WEBP).");
      return;
    }

    // Validate file size (max 10MB)
    if (file.size > 10 * 1024 * 1024) {
      setError("Image is too large. Please upload an image under 10MB.");
      return;
    }

    setError("");

    const reader = new FileReader();
    reader.onload = (e) => {
      const dataUrl = e.target?.result as string;
      setUploadedImage(dataUrl);
      extractTextFromImage(dataUrl);
    };
    reader.onerror = () => {
      setError("Failed to read the image file. Please try again.");
    };
    reader.readAsDataURL(file);
  }, [extractTextFromImage]);

  // --- Drag and drop handlers ---
  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);

    const files = e.dataTransfer.files;
    if (files.length > 0) {
      handleImageFile(files[0]);
    }
  }, [handleImageFile]);

  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      handleImageFile(files[0]);
    }
    // Reset so same file can be re-selected
    if (fileInputRef.current) fileInputRef.current.value = "";
  }, [handleImageFile]);

  const clearImage = useCallback(() => {
    setUploadedImage(null);
    setOcrStatus("idle");
    setOcrProgress(0);
  }, []);

  // --- Resume analysis ---
  async function handleAnalyze() {
    if (!resumeText.trim() || resumeText.trim().length < 10) {
      setError("Please enter at least 10 characters of resume text.");
      return;
    }

    setLoading(true);
    setError("");
    setAnalysis(null);

    try {
      const res = await fetch("/api/resume/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content: resumeText }),
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.error || "Analysis failed. Please try again.");
        return;
      }

      setAnalysis(data);
      setActiveTab("results");
      fetchHistory();
      setTimeout(() => {
        resultRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
      }, 100);
    } catch {
      setError("Network error. Please check your connection and try again.");
    } finally {
      setLoading(false);
    }
  }

  async function loadHistoryItem(item: HistoryItem) {
    setLoading(true);
    setError("");
    try {
      const res = await fetch(`/api/resume/${item.id}`);
      if (res.ok) {
        const data = await res.json();
        setAnalysis({
          id: data.id,
          resumeId: data.resumeId,
          overallScore: data.overallScore,
          summary: data.summary,
          strengths: data.strengths,
          weaknesses: data.weaknesses,
          suggestions: data.suggestions,
          dimensionScores: data.dimensionScores,
          improvedResume: data.improvedResume,
          createdAt: data.createdAt,
        });
        setActiveTab("results");
        setTimeout(() => {
          resultRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
        }, 100);
      }
    } catch {
      setError("Failed to load analysis.");
    } finally {
      setLoading(false);
    }
  }

  function getScoreColor(score: number): string {
    if (score >= 80) return "text-emerald-600";
    if (score >= 60) return "text-amber-500";
    if (score >= 40) return "text-orange-500";
    return "text-red-500";
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-100">
      {/* Header */}
      <header className="border-b border-slate-200 bg-white/80 backdrop-blur-md sticky top-0 z-10">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-600 to-purple-600 text-white font-bold text-lg shadow-md">
              AR
            </div>
            <div>
              <h1 className="text-xl font-bold text-slate-900">AI Resume Analyzer</h1>
              <p className="text-xs text-slate-500 -mt-0.5">Score, optimize &amp; improve</p>
            </div>
          </div>
          <button
            onClick={() => {
              setAnalysis(null);
              setResumeText("");
              setUploadedImage(null);
              setOcrStatus("idle");
              setOcrProgress(0);
              setActiveTab("results");
              window.scrollTo({ top: 0, behavior: "smooth" });
            }}
            className="rounded-lg bg-slate-100 px-4 py-2 text-sm font-medium text-slate-700 transition-colors hover:bg-slate-200"
          >
            New Analysis
          </button>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-6 py-8">
        {/* Input Section */}
        <section className="mb-10">
          <div className="rounded-2xl bg-white p-8 shadow-[0_8px_30px_rgb(0,0,0,0.06)] border border-slate-200/60">
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-slate-900">Upload or Paste Your Resume</h2>
              <p className="mt-1 text-sm text-slate-500">
                Upload an image of your resume (PNG/JPG) and we&apos;ll extract the text, or paste it directly.
              </p>
            </div>

            {/* Image Upload Area */}
            <div className="mb-6">
              <div
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
                onClick={() => fileInputRef.current?.click()}
                className={`relative cursor-pointer rounded-xl border-2 border-dashed p-6 text-center transition-all ${
                  isDragging
                    ? "border-indigo-400 bg-indigo-50"
                    : uploadedImage
                      ? "border-emerald-300 bg-emerald-50/50"
                      : "border-slate-200 bg-slate-50 hover:border-indigo-300 hover:bg-indigo-50/30"
                }`}
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/png,image/jpeg,image/jpg,image/webp"
                  onChange={handleFileSelect}
                  className="hidden"
                />

                {uploadedImage ? (
                  <div className="flex flex-col items-center gap-3">
                    <div className="relative">
                      <img
                        src={uploadedImage}
                        alt="Uploaded resume"
                        className="max-h-40 rounded-lg object-contain shadow-sm"
                      />
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          clearImage();
                        }}
                        className="absolute -right-2 -top-2 flex h-6 w-6 items-center justify-center rounded-full bg-red-500 text-white shadow transition-colors hover:bg-red-600"
                      >
                        <svg className="h-3.5 w-3.5" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" d="M6 18 18 6M6 6l12 12" />
                        </svg>
                      </button>
                    </div>

                    {/* OCR Status */}
                    {ocrStatus === "processing" && (
                      <div className="w-full max-w-xs">
                        <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
                          <span>Extracting text from image...</span>
                          <span>{ocrProgress}%</span>
                        </div>
                        <div className="h-2 w-full overflow-hidden rounded-full bg-slate-200">
                          <div
                            className="h-full rounded-full bg-gradient-to-r from-indigo-500 to-purple-500 transition-all duration-300"
                            style={{ width: `${ocrProgress}%` }}
                          />
                        </div>
                      </div>
                    )}

                    {ocrStatus === "done" && (
                      <span className="inline-flex items-center gap-1 rounded-full bg-emerald-100 px-3 py-1 text-xs font-medium text-emerald-700">
                        <svg className="h-3.5 w-3.5" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" d="m4.5 12.75 6 6 9-13.5" />
                        </svg>
                        Text extracted — review and edit below
                      </span>
                    )}

                    {ocrStatus === "error" && (
                      <span className="inline-flex items-center gap-1 rounded-full bg-red-100 px-3 py-1 text-xs font-medium text-red-700">
                        <svg className="h-3.5 w-3.5" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m9-.75a9 9 0 1 1-18 0 9 9 0 0 1 18 0Zm-9 3.75h.008v.008H12v-.008Z" />
                        </svg>
                        OCR failed — click to retry or paste text
                      </span>
                    )}

                    <p className="text-xs text-slate-400">Click or drag to replace image</p>
                  </div>
                ) : (
                  <div className="flex flex-col items-center gap-2 py-4">
                    <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-indigo-100">
                      <svg className="h-6 w-6 text-indigo-500" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 0 0 5.25 21h13.5A2.25 2.25 0 0 0 21 18.75V16.5m-13.5-9L12 3m0 0 4.5 4.5M12 3v13.5" />
                      </svg>
                    </div>
                    <p className="text-sm font-medium text-slate-600">
                      Drop a resume image here or click to browse
                    </p>
                    <p className="text-xs text-slate-400">
                      PNG, JPG or WEBP &middot; Max 10MB
                    </p>
                  </div>
                )}
              </div>
            </div>

            {/* Divider */}
            <div className="relative mb-6">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-slate-200" />
              </div>
              <div className="relative flex justify-center text-xs">
                <span className="bg-white px-3 text-slate-400">Or paste your resume text below</span>
              </div>
            </div>

            {/* Textarea */}
            <textarea
              value={resumeText}
              onChange={(e) => {
                setResumeText(e.target.value);
                if (error) setError("");
              }}
              placeholder={`Paste your resume here...\n\nTip: Include your work experience, skills, education, and achievements for the best analysis.`}
              className="min-h-[220px] w-full rounded-xl border border-slate-200 bg-slate-50 p-5 text-sm leading-relaxed text-slate-800 placeholder:text-slate-400 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-100 transition-all resize-y"
            />

            {error && (
              <div className="mt-3 flex items-start gap-2 rounded-lg bg-red-50 p-3 text-sm text-red-600 border border-red-100">
                <svg className="mt-0.5 h-4 w-4 shrink-0" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126ZM12 15.75h.007v.008H12v-.008Z" />
                </svg>
                <span>{error}</span>
              </div>
            )}

            <div className="mt-5 flex items-center gap-3">
              <button
                onClick={handleAnalyze}
                disabled={loading || !resumeText.trim() || ocrStatus === "processing"}
                className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 px-6 py-3 text-sm font-semibold text-white shadow-md shadow-indigo-200 transition-all hover:from-indigo-700 hover:to-purple-700 hover:shadow-lg disabled:cursor-not-allowed disabled:opacity-50"
              >
                {loading ? (
                  <>
                    <svg className="h-4 w-4 animate-spin" viewBox="0 0 24 24" fill="none">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                    </svg>
                    Analyzing...
                  </>
                ) : (
                  <>
                    <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" d="m3.75 13.5 10.5-11.25L12 10.5h8.25L9.75 21.75 12 13.5H3.75Z" />
                    </svg>
                    Analyze Resume
                  </>
                )}
              </button>
              <span className="text-xs text-slate-400">
                {resumeText.trim().split(/\s+/).filter(Boolean).length || 0} words
              </span>
            </div>
          </div>
        </section>

        {/* Results Section */}
        {analysis && (
          <div ref={resultRef} className="mb-10">
            {/* Score Overview Card */}
            <div className="mb-6 rounded-2xl bg-white p-8 shadow-[0_8px_30px_rgb(0,0,0,0.06)] border border-slate-200/60">
              <div className="flex flex-col items-center gap-6 sm:flex-row sm:items-start">
                {/* Score Gauge */}
                <div className="flex shrink-0 flex-col items-center">
                  <div className="relative flex h-36 w-36 items-center justify-center">
                    <svg className="h-full w-full -rotate-90" viewBox="0 0 120 120">
                      <circle cx="60" cy="60" r="52" fill="none" stroke="#e5e7eb" strokeWidth="10" />
                      <circle
                        cx="60" cy="60" r="52"
                        fill="none"
                        stroke={analysis.overallScore >= 80 ? "#10b981" : analysis.overallScore >= 60 ? "#f59e0b" : analysis.overallScore >= 40 ? "#f97316" : "#ef4444"}
                        strokeWidth="10"
                        strokeLinecap="round"
                        strokeDasharray={`${(analysis.overallScore / 100) * 326.73} 326.73`}
                        className="transition-all duration-1000 ease-out"
                      />
                    </svg>
                    <span className={`absolute text-3xl font-bold ${getScoreColor(analysis.overallScore)}`}>
                      {analysis.overallScore}
                    </span>
                  </div>
                  <span className="mt-1 text-xs font-medium text-slate-400">out of 100</span>
                </div>

                {/* Summary & Stats */}
                <div className="flex-1">
                  <h3 className="text-lg font-bold text-slate-900">Analysis Results</h3>
                  <p className="mt-2 text-sm leading-relaxed text-slate-600">{analysis.summary}</p>

                  <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-5">
                    {Object.entries(analysis.dimensionScores).map(([key, value]) => (
                      <div key={key} className="rounded-xl bg-slate-50 p-3 text-center border border-slate-100">
                        <div className="text-lg font-bold" style={{ color: value >= 70 ? "#10b981" : value >= 50 ? "#f59e0b" : "#ef4444" }}>
                          {Math.round(value)}
                        </div>
                        <div className="text-[10px] font-medium text-slate-500 leading-tight mt-0.5">{key}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Tabs */}
            <div className="mb-4 flex gap-1 rounded-xl bg-slate-100 p-1 w-fit flex-wrap">
              {[
                { key: "results" as const, label: "Detailed Analysis", icon: "M9 12h3.75M9 15h3.75M9 18h3.75m3 .75H18a2.25 2.25 0 002.25-2.25V6.108c0-1.135-.845-2.098-1.976-2.192a48.424 48.424 0 00-1.123-.08m-5.801 0c-.065.21-.1.433-.1.664 0 .414.336.75.75.75h4.5a.75.75 0 00.75-.75 2.25 2.25 0 00-.1-.664m-5.8 0A2.251 2.251 0 0113.5 2.25H15c1.012 0 1.867.668 2.15 1.586m-5.8 0c-.376.023-.75.05-1.124.08C9.095 4.01 8.25 4.973 8.25 6.108V8.25m0 0H4.875c-.621 0-1.125.504-1.125 1.125v11.25c0 .621.504 1.125 1.125 1.125h9.75c.621 0 1.125-.504 1.125-1.125V9.375c0-.621-.504-1.125-1.125-1.125H8.25ZM6.75 12h.008v.008H6.75V12Zm0 3h.008v.008H6.75V15Zm0 3h.008v.008H6.75V18Z" },
                { key: "improved" as const, label: "Improved Resume", icon: "M12 3v17.25m0 0c-1.472 0-2.882.265-4.185.75M12 20.25c1.472 0 2.882.265 4.185.75M18.75 4.97A48.416 48.416 0 0012 4.5c-2.291 0-4.545.16-6.75.47m13.5 0c1.01.143 2.01.317 3 .52m-3-.52l2.62 10.726c.122.499-.106 1.028-.589 1.202a5.988 5.988 0 01-2.031.352 5.988 5.988 0 01-2.031-.352c-.483-.174-.711-.703-.589-1.202L18.75 4.971zm-12 0l-2.62 10.726c-.122.499.106 1.028.589 1.202a5.988 5.988 0 002.031.352 5.988 5.988 0 002.031-.352c.483-.174.711-.703.589-1.202L6.75 4.97z" },
              ].map((tab) => (
                <button
                  key={tab.key}
                  onClick={() => setActiveTab(tab.key)}
                  className={`flex items-center gap-1.5 rounded-lg px-4 py-2 text-sm font-medium transition-all ${
                    activeTab === tab.key
                      ? "bg-white text-indigo-700 shadow-sm"
                      : "text-slate-500 hover:text-slate-700"
                  }`}
                >
                  <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" d={tab.icon} />
                  </svg>
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Tab Content */}
            <div className="rounded-2xl bg-white p-8 shadow-[0_8px_30px_rgb(0,0,0,0.06)] border border-slate-200/60">
              {activeTab === "results" && (
                <div className="grid gap-8 md:grid-cols-2">
                  {/* Strengths */}
                  <div>
                    <div className="mb-3 flex items-center gap-2">
                      <div className="flex h-7 w-7 items-center justify-center rounded-full bg-emerald-100">
                        <svg className="h-4 w-4 text-emerald-600" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
                        </svg>
                      </div>
                      <h3 className="font-bold text-slate-900">Strengths</h3>
                    </div>
                    {analysis.strengths.length > 0 ? (
                      <ul className="space-y-2">
                        {analysis.strengths.map((s, i) => (
                          <li key={i} className="flex items-start gap-2 text-sm text-slate-600">
                            <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-emerald-400" />
                            <span>{s}</span>
                          </li>
                        ))}
                      </ul>
                    ) : (
                      <p className="text-sm text-slate-400 italic">No specific strengths identified yet.</p>
                    )}
                  </div>

                  {/* Weaknesses */}
                  <div>
                    <div className="mb-3 flex items-center gap-2">
                      <div className="flex h-7 w-7 items-center justify-center rounded-full bg-red-100">
                        <svg className="h-4 w-4 text-red-500" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m9-.75a9 9 0 1 1-18 0 9 9 0 0 1 18 0Zm-9 3.75h.008v.008H12v-.008Z" />
                        </svg>
                      </div>
                      <h3 className="font-bold text-slate-900">Areas to Improve</h3>
                    </div>
                    {analysis.weaknesses.length > 0 ? (
                      <ul className="space-y-2">
                        {analysis.weaknesses.map((w, i) => (
                          <li key={i} className="flex items-start gap-2 text-sm text-slate-600">
                            <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-red-400" />
                            <span>{w}</span>
                          </li>
                        ))}
                      </ul>
                    ) : (
                      <p className="text-sm text-slate-400 italic">No significant weaknesses found.</p>
                    )}
                  </div>

                  {/* Suggestions */}
                  <div className="md:col-span-2">
                    <div className="mb-3 flex items-center gap-2">
                      <div className="flex h-7 w-7 items-center justify-center rounded-full bg-indigo-100">
                        <svg className="h-4 w-4 text-indigo-600" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" d="M12 18v-5.25m0 0a6.01 6.01 0 0 0 1.5-.189m-1.5.189a6.01 6.01 0 0 1-1.5-.189m3.75 7.478a12.06 12.06 0 0 1-4.5 0m3.75 2.383a14.406 14.406 0 0 1-3 0M14.25 18v-.192c0-.983.658-1.823 1.508-2.316a7.5 7.5 0 1 0-7.517 0c.85.493 1.509 1.333 1.509 2.316V18" />
                        </svg>
                      </div>
                      <h3 className="font-bold text-slate-900">Actionable Suggestions</h3>
                    </div>
                    {analysis.suggestions.length > 0 ? (
                      <ol className="space-y-3">
                        {analysis.suggestions.map((s, i) => (
                          <li key={i} className="flex items-start gap-3 rounded-xl bg-indigo-50/60 p-4 border border-indigo-100">
                            <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-indigo-600 text-xs font-bold text-white">
                              {i + 1}
                            </span>
                            <span className="text-sm text-slate-700">{s}</span>
                          </li>
                        ))}
                      </ol>
                    ) : (
                      <p className="text-sm text-slate-400 italic">No suggestions — your resume looks great!</p>
                    )}
                  </div>
                </div>
              )}

              {activeTab === "improved" && (
                <div>
                  <div className="mb-4 flex items-center justify-between">
                    <div>
                      <h3 className="font-bold text-slate-900">Optimized Resume</h3>
                      <p className="text-xs text-slate-500 mt-0.5">
                        This AI-generated improved version follows ATS-friendly formatting and includes best practices.
                      </p>
                    </div>
                    <button
                      onClick={() => {
                        if (analysis) {
                          navigator.clipboard.writeText(analysis.improvedResume);
                        }
                      }}
                      className="flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-4 py-2 text-xs font-medium text-slate-600 transition-colors hover:bg-slate-50"
                    >
                      <svg className="h-3.5 w-3.5" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 7.5V6.108c0-1.135.845-2.098 1.976-2.192.373-.03.748-.057 1.123-.08M15.75 18H18a2.25 2.25 0 002.25-2.25V6.108c0-1.135-.845-2.098-1.976-2.192a48.424 48.424 0 00-1.123-.08M15.75 18.75v-1.875a3.375 3.375 0 00-3.375-3.375h-1.5a1.125 1.125 0 01-1.125-1.125v-1.5A3.375 3.375 0 006.375 7.5H5.25m11.9-3.664A2.251 2.251 0 0015 2.25h-1.5a2.25 2.25 0 00-2.15 1.586m5.8 0c.065.21.1.433.1.664v.75h-6V4.5c0-.231.035-.454.1-.664M6.75 7.5H4.875c-.621 0-1.125.504-1.125 1.125v12c0 .621.504 1.125 1.125 1.125h9.75c.621 0 1.125-.504 1.125-1.125V16.5a9 9 0 00-9-9z" />
                      </svg>
                      Copy
                    </button>
                  </div>
                  <pre className="overflow-x-auto rounded-xl bg-slate-900 p-6 text-sm leading-relaxed text-slate-100 whitespace-pre-wrap font-mono">
                    {analysis.improvedResume}
                  </pre>
                </div>
              )}
            </div>
          </div>
        )}

        {/* History Section */}
        <section className="rounded-2xl bg-white p-8 shadow-[0_8px_30px_rgb(0,0,0,0.06)] border border-slate-200/60">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold text-slate-900">Analysis History</h2>
              <p className="text-xs text-slate-500 mt-0.5">Previously analyzed resumes</p>
            </div>
            <button
              onClick={fetchHistory}
              disabled={loadingHistory}
              className="flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-500 transition-colors hover:bg-slate-50"
            >
              <svg className={`h-3.5 w-3.5 ${loadingHistory ? "animate-spin" : ""}`} fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" d="M16.023 9.348h4.992v-.001M2.985 19.644v-4.992m0 0h4.992m-4.993 0 3.181 3.183a8.25 8.25 0 0013.803-3.7M4.031 9.865a8.25 8.25 0 0113.803-3.7l3.181 3.182" />
              </svg>
              Refresh
            </button>
          </div>

          {loadingHistory ? (
            <div className="flex items-center justify-center py-10 text-sm text-slate-400">
              <svg className="mr-2 h-4 w-4 animate-spin" viewBox="0 0 24 24" fill="none">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
              </svg>
              Loading history...
            </div>
          ) : history.length === 0 ? (
            <div className="rounded-xl bg-slate-50 py-10 text-center">
              <svg className="mx-auto h-10 w-10 text-slate-300" fill="none" viewBox="0 0 24 24" strokeWidth={1} stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" d="M9 12h3.75M9 15h3.75M9 18h3.75m3 .75H18a2.25 2.25 0 002.25-2.25V6.108c0-1.135-.845-2.098-1.976-2.192a48.424 48.424 0 00-1.123-.08m-5.801 0c-.065.21-.1.433-.1.664 0 .414.336.75.75.75h4.5a.75.75 0 00.75-.75 2.25 2.25 0 00-.1-.664m-5.8 0A2.251 2.251 0 0113.5 2.25H15c1.012 0 1.867.668 2.15 1.586m-5.8 0c-.376.023-.75.05-1.124.08C9.095 4.01 8.25 4.973 8.25 6.108V8.25m0 0H4.875c-.621 0-1.125.504-1.125 1.125v11.25c0 .621.504 1.125 1.125 1.125h9.75c.621 0 1.125-.504 1.125-1.125V9.375c0-.621-.504-1.125-1.125-1.125H8.25ZM6.75 12h.008v.008H6.75V12Zm0 3h.008v.008H6.75V15Zm0 3h.008v.008H6.75V18Z" />
              </svg>
              <p className="mt-3 text-sm text-slate-400">No analyses yet. Upload or paste a resume above to get started!</p>
            </div>
          ) : (
            <div className="space-y-2">
              {history.map((item) => (
                <button
                  key={item.id}
                  onClick={() => loadHistoryItem(item)}
                  className="w-full rounded-xl border border-slate-100 bg-slate-50/50 p-4 text-left transition-all hover:border-indigo-200 hover:bg-indigo-50/50"
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium text-slate-700">
                        {item.preview || "Resume analysis"}
                      </p>
                      <p className="mt-0.5 text-xs text-slate-400">
                        {new Date(item.createdAt).toLocaleDateString("en-US", {
                          month: "short",
                          day: "numeric",
                          year: "numeric",
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                      </p>
                    </div>
                    <div className="flex shrink-0 items-center gap-2">
                      <span
                        className={`rounded-lg px-2.5 py-1 text-xs font-bold ${
                          item.overallScore >= 80
                            ? "bg-emerald-100 text-emerald-700"
                            : item.overallScore >= 60
                              ? "bg-amber-100 text-amber-700"
                              : "bg-red-100 text-red-700"
                        }`}
                      >
                        {item.overallScore}/100
                      </span>
                      <svg className="h-4 w-4 text-slate-300" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                      </svg>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          )}
        </section>

        {/* Footer */}
        <footer className="mt-10 text-center text-xs text-slate-400 pb-6">
          <p>AI Resume Analyzer — Powered by intelligent analysis engine &amp; Tesseract.js OCR. Always review AI-generated content before submitting.</p>
        </footer>
      </main>
    </div>
  );
}
