import { drizzle } from "drizzle-orm/postgres-js";
import postgres from "postgres";

const globalForDb = globalThis as typeof globalThis & {
  __arenaNextJsPostgresJsSql?: ReturnType<typeof postgres>;
};

function getSql(): ReturnType<typeof postgres> {
  if (globalForDb.__arenaNextJsPostgresJsSql) {
    return globalForDb.__arenaNextJsPostgresJsSql;
  }
  const databaseUrl = process.env.DATABASE_URL;
  if (!databaseUrl) {
    throw new Error("DATABASE_URL is required");
  }
  const sql = postgres(databaseUrl, {
    // Disable prepared statements in serverless — they don't persist between invocations
    prepare: false,
  });
  if (process.env.NODE_ENV !== "production") {
    globalForDb.__arenaNextJsPostgresJsSql = sql;
  }
  return sql;
}

let cachedDb: ReturnType<typeof drizzle> | null = null;

function ensureDb(): ReturnType<typeof drizzle> {
  if (!cachedDb) {
    cachedDb = drizzle(getSql());
  }
  return cachedDb;
}

/**
 * Lazy database proxy.
 * The error for a missing DATABASE_URL is deferred until the first actual
 * method call, so importing this module during build (e.g. on Netlify)
 * won't crash. All drizzle methods are properly bound to the underlying
 * instance so chaining like db.select().from() works correctly.
 *
 * Uses `postgres` (pure JS, zero native C++ bindings) via `drizzle-orm/postgres-js`
 * so Netlify's esbuild bundler bundles the serverless functions without issues.
 */
export const db = new Proxy(
  {} as ReturnType<typeof drizzle>,
  {
    get(_target, prop, _receiver) {
      const realDb = ensureDb();
      const value = (realDb as any)[prop];
      if (typeof value === "function") {
        return value.bind(realDb);
      }
      return value;
    },
  }
);
