import { pgTable, serial, text, integer, timestamp, jsonb } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";

export const resumes = pgTable("resumes", {
  id: serial("id").primaryKey(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const resumeAnalyses = pgTable("resume_analyses", {
  id: serial("id").primaryKey(),
  resumeId: integer("resume_id")
    .references(() => resumes.id, { onDelete: "cascade" })
    .notNull(),
  overallScore: integer("overall_score").notNull(),
  summary: text("summary").notNull(),
  strengths: jsonb("strengths").notNull().$type<string[]>(),
  weaknesses: jsonb("weaknesses").notNull().$type<string[]>(),
  suggestions: jsonb("suggestions").notNull().$type<string[]>(),
  dimensionScores: jsonb("dimension_scores").notNull().$type<Record<string, number>>(),
  improvedResume: text("improved_resume").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const resumesRelations = relations(resumes, ({ many }) => ({
  analyses: many(resumeAnalyses),
}));

export const resumeAnalysesRelations = relations(resumeAnalyses, ({ one }) => ({
  resume: one(resumes, {
    fields: [resumeAnalyses.resumeId],
    references: [resumes.id],
  }),
}));
